package com.aprende.lianjapaun;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout box;
    String[][] vocab = {
        {"ありがとう","ありがとう","arigatou","Obrigadu"},
        {"おはようございます","おはようございます","ohayou gozaimasu","Bon dadeer"},
        {"こんにちは","こんにちは","konnichiwa","Bondia / Botarde"},
        {"こんばんは","こんばんは","konbanwa","Bona kalan"},
        {"お茶","おちゃ","ocha","Xa"},
        {"友達","ともだち","tomodachi","Maluk"},
        {"仕事","しごと","shigoto","Servisu"},
        {"日本","にほん","nihon","Japaun"}
    };
    @Override public void onCreate(Bundle b){
        super.onCreate(b); showHome();
    }
    TextView t(String s,int size){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(Color.DKGRAY);
        v.setPadding(24,18,24,18); return v;
    }
    void base(String title){
        box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,20,20,20);
        ScrollView sv=new ScrollView(this); sv.addView(box); setContentView(sv);
        TextView h=t(title,25); h.setTextColor(Color.rgb(20,70,130)); box.addView(h);
    }
    Button btn(String s, View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setOnClickListener(l); box.addView(b); return b; }
    void showHome(){
        base("APRENDE LIAN JAPAUN");
        box.addView(t("Japonês → Tetun • Inglês\nOffline • JLPT N5 → N1",18));
        btn("📘 Lisaun N5",v->level("N5"));
        btn("📗 Lisaun N4",v->level("N4"));
        btn("📕 Lisaun N3",v->level("N3"));
        btn("📙 Lisaun N2",v->level("N2"));
        btn("📓 Lisaun N1",v->level("N1"));
        btn("🈶 Kanji",v->kanji());
        btn("💬 Kaiwa",v->kaiwa());
        btn("✏️ Prátika",v->practice());
        btn("⚙️ Definisaun",v->settings());
    }
    void level(String lv){
        base("Lisaun "+lv);
        box.addView(t("Kotoba • Verbos • Bunpo • Partículas",18));
        for(String[] x:vocab) box.addView(t(x[0]+"\n"+x[1]+"\n"+x[2]+"\nTetun: "+x[3],17));
        btn("⬅ Fila ba menu",v->showHome());
    }
    void kanji(){
        base("Kanji");
        String[] k={"日 にち / hi — loron","本 ほん / hon — livru","人 ひと / hito — ema","山 やま / yama — foho","川 かわ / kawa — mota","学 がく / gaku — aprende","生 せい / sei — moris","語 ご / go — lian"};
        for(String s:k) box.addView(t(s,18));
        btn("⬅ Fila ba menu",v->showHome());
    }
    void kaiwa(){
        base("Kaiwa");
        box.addView(t("A: おはようございます。\nB: おはようございます。\nA: 仕事へ行きますか。\nB: はい、行きます。\n\nTetun:\nA: Bon dadeer.\nB: Bon dadeer.\nA: Ita ba servisu?\nB: Sim, hau ba.",18));
        btn("⬅ Fila ba menu",v->showHome());
    }
    void practice(){
        base("Prátika JLPT");
        for(int i=1;i<=10;i++) box.addView(t(i+". Tradús ba Japonês: Hau servisu iha Japaun.",17));
        box.addView(t("\nResponde iha Japonês. Depois haree resposta.",17));
        btn("⬅ Fila ba menu",v->showHome());
    }
    void settings(){
        base("Definisaun");
        box.addView(t("Lian interface: Tetun tuir padraun\nConteúdo: Japonês + Hiragana + Romaji + Tetun\nModo: Offline",18));
        btn("⬅ Fila ba menu",v->showHome());
    }
}